const express = require('express');

const app = express();
app.use(express.json());

const NGL_API = 'https://ngl.link/api/submit';

function randomDeviceId() {
    return 'id-' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
}

async function sendMessage(username, message, deviceId) {
    try {
        const response = await fetch(NGL_API, {
            method: 'POST',
            headers: {
                'content-type': 'application/json',
                'origin': 'https://ngl.link',
                'referer': `https://ngl.link/${username}`,
                'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36'
            },
            body: JSON.stringify({
                username: username,
                question: message,
                deviceId: deviceId
            })
        });

        if (response.ok) {
            const data = await response.json().catch(() => ({}));
            return { success: true, status: response.status, data };
        } else {
            const text = await response.text().catch(() => '');
            return { success: false, status: response.status, error: text };
        }
    } catch (err) {
        return { success: false, error: err.message };
    }
}

async function sendBulk(username, message, count, concurrency = 10) {
    let enviados = 0;
    let falhas = 0;

    for (let i = 0; i < count; i += concurrency) {
        const batch = [];
        const batchSize = Math.min(concurrency, count - i);

        for (let j = 0; j < batchSize; j++) {
            const deviceId = randomDeviceId();
            batch.push(sendMessage(username, message, deviceId));
        }

        const results = await Promise.all(batch);

        for (const res of results) {
            if (res.success) enviados++;
            else falhas++;
        }
    }

    return { enviados, falhas, total: count };
}

app.post('/api/spamngl', async (req, res) => {
    const { username, message, count = 1, concurrency = 10 } = req.body;

    if (!username || !message) {
        return res.status(400).json({
            error: 'username e message são obrigatórios',
            exemplo: {
                username: 'firmose',
                message: 'hh',
                count: 30,
                concurrency: 10
            }
        });
    }

    const qtd = Math.min(parseInt(count) || 1, 5000);
    const conc = Math.min(parseInt(concurrency) || 10, 50);

    console.log(`[SPAM NGL] Enviando ${qtd}x para @${username} | msg: "${message}"`);

    const start = Date.now();
    const stats = await sendBulk(username, message, qtd, conc);
    const tempo = ((Date.now() - start) / 1000).toFixed(2);

    res.json({
        status: '「 NGL enviado 」',
        para: `@${username}`,
        enviados: `${stats.enviados}/${stats.total}`,
        falhou: stats.falhas,
        mensagem: message,
        tempo_segundos: tempo
    });
});

app.get('/', (req, res) => {
    res.json({
        status: 'API Spam NGL rodando',
        endpoints: {
            spam: 'POST /api/spamngl',
            exemplo_body: {
                username: 'firmose',
                message: 'hh',
                count: 30,
                concurrency: 10
            }
        }
    });
});

const PORT = process.env.PORT || 2010;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
    console.log(`📌 POST http://localhost:${PORT}/api/spamngl`);
});
